import Navbar from "../components/navbar/navbar";
import Projekan from "../components/projekan/projekan";

function Projects() {
  return (
    <div className="App">
      <Navbar />
      <Projekan />
    </div>
  );
}

export default Projects;
